//
//  VendingItemCell.swift
//  VendingMachine
//
//  Created by Pasan Premaratne on 12/1/16.
//  Copyright © 2016 Treehouse Island, Inc. All rights reserved.
//

import UIKit

class VendingItemCell: UICollectionViewCell {
    
    @IBOutlet weak var iconView: UIImageView!
}
